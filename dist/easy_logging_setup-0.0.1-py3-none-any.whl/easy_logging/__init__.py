from .main import EasyLoggingSetup
