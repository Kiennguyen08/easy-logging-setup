from .main import EasyLoggingSetup
from .easylogging import EasyLogging
