import os
import yaml
import logging.config

# Load the configuration from the file
with open("./log-config.yml", "r") as f:
    config = yaml.safe_load(f.read())


class Logging:
    def __init__(self) -> None:
        self.enable_json_mode = os.getenv("JSON_MODE", False)
        self._setup()

    def _setup(self):
        if self.enable_json_mode:
            config["handlers"]["default"]["formatter"] = "json"
        print(config)
        logging.config.dictConfig(config)


if __name__ == "__main__":
    Logging()
    logger = logging.getLogger()
    logger.info("AAAA")
    logger.bi
